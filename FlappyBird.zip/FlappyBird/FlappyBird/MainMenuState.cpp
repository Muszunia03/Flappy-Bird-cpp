#include <sstream>
#include "MainMenuState.h"
#include "GameState.h"
import Definitions;
#include <iostream>

MainMenuState::MainMenuState(GameDataRef data) : _data(data)
{

}
void MainMenuState::Init()
{
	this->_data->assets.LoadTextures("Main Menu Background", Definitions::MAIN_MENU_BACKGROUND_FILEPATH);
	this->_data->assets.LoadTextures("Game Title", Definitions::GAME_TITLE_FILEPATH);
	this->_data->assets.LoadTextures("Play Button", Definitions::GAME_BUTTON_FILEPATH);
	_background.setTexture(this->_data->assets.GetTexture("Main Menu Background"));
	_title.setTexture(this->_data->assets.GetTexture("Game Title"));
	_playButton.setTexture(this->_data->assets.GetTexture("Play Button"));
	_title.setPosition((Definitions::SCREEN_WIDTH / 2) - (_title.getGlobalBounds().width / 2), _title.getGlobalBounds().height / 2);
	_playButton.setPosition((Definitions::SCREEN_WIDTH / 2) - (_playButton.getGlobalBounds().width / 2), (Definitions::SCREEN_HEIGHT / 2) - (_playButton.getGlobalBounds().height / 2));

}
void MainMenuState::HandleInput()
{
	sf::Event event;
	while (this->_data->window.pollEvent(event))
	{
		if (sf::Event::Closed == event.type)
		{
			this->_data->window.close();
		}
		if (this->_data->input.IsSpriteClicked(this->_playButton, sf::Mouse::Left, this->_data->window))
		{
			
			_data->machine.AddState(StateRef(new GameState(_data)), true);
			
			
		}
	}
}
void MainMenuState::Update(float dt)
{
	
}
void MainMenuState::Draw(float dt)
{
	_data->window.clear();
	_data->window.draw(_background);
	_data->window.draw(_title);
	_data->window.draw(_playButton);
	_data->window.display();
}