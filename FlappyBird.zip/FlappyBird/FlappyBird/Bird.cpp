#include "Bird.h"

Bird::Bird(GameDataRef data) : _data(data), birdState(BIRD_STATE_FALLING), rotation(0.0f)
{
    InitializeBird();
}

void Bird::InitializeBird()
{
    birdTexture.loadFromFile(Definitions::BIRD_FILEPATH);
    birdSprite.setTexture(birdTexture);

    birdSprite.setPosition((_data->window.getSize().x / 4) - (birdSprite.getGlobalBounds().width / 2), _data->window.getSize().y / 2);
}

void Bird::DrawBird()
{
    _data->window.draw(birdSprite);
}

void Bird::Update(float dt)
{
    if (BIRD_STATE_FALLING == birdState)
    {
        birdSprite.move(0, gravity * dt);

        rotation += rotationSpeed * dt;

        if (rotation > 25.0f)
        {
            rotation = 25.0f;
        }

        birdSprite.setRotation(rotation);
    }
    else if (BIRD_STATE_FLYING == birdState)
    {
        birdSprite.move(0, -jumpVelocity * dt);

        rotation -= rotationSpeed * dt;

        if (rotation < -25.0f)
        {
            rotation = -25.0f;
        }

        birdSprite.setRotation(rotation);
    }

    if (clock.getElapsedTime().asSeconds() > FLYING_DURATION)
    {
        clock.restart();
        birdState = BIRD_STATE_FALLING;
    }

    if (birdSprite.getPosition().y < 0)
    {
        birdSprite.setPosition(birdSprite.getPosition().x, 0);
    }

    if (birdSprite.getPosition().y > _data->window.getSize().y - birdSprite.getGlobalBounds().height)
    {
        birdSprite.setPosition(birdSprite.getPosition().x, _data->window.getSize().y - birdSprite.getGlobalBounds().height);
        birdState = BIRD_STATE_FALLING; 
    }
}

void Bird::Tap()
{
    clock.restart();
    birdState = BIRD_STATE_FLYING;
}

bool Bird::CheckCollision(const std::vector<sf::Sprite>& pipeSprites, const std::vector<sf::Sprite>& ground)
{
    for (auto& pipe : pipeSprites)
    {
        if (birdSprite.getGlobalBounds().intersects(pipe.getGlobalBounds()))
        {
            return true;
        }
    }
    for (auto& land : ground)
    {
        if (birdSprite.getGlobalBounds().intersects(land.getGlobalBounds()))
        {
            return true;
        }
    }
    return false;
}