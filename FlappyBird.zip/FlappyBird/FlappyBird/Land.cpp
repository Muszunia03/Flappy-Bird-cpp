#include "Land.h"
import Definitions;

Land::Land(GameDataRef data) : _data(data) {
	sf::Sprite sprite(_data->assets.GetTexture("Land"));
	sf::Sprite sprite2(_data->assets.GetTexture("Land"));
	sprite.setPosition(0, _data->window.getSize().y - sprite.getGlobalBounds().height);
	sprite2.setPosition(sprite.getGlobalBounds().width, _data->window.getSize().y - sprite.getGlobalBounds().height);
	landSpr.push_back(sprite);
	landSpr.push_back(sprite2);
};
void Land::MoveLand(float dt)
{
	for (unsigned short int i = 0; i < landSpr.size(); i++)
	{
		float movement = Definitions::PIPE_MOVEMENT_SPEED*dt;
		landSpr.at(i).move(-movement, 0.0f);
		if (landSpr.at(i).getPosition().x < 0 - landSpr.at(i).getGlobalBounds().width)
		{
			sf::Vector2f pos(_data->window.getSize().x, landSpr.at(i).getPosition().y);
			landSpr.at(i).setPosition(pos);
		}
	}
}
void Land::DrawLand()
{
	for (unsigned short int i = 0; i < landSpr.size(); i++)
	{
		_data->window.draw(landSpr.at(i));
	}
}