#pragma once

#include <SFML/Graphics.hpp>
#include "State.h"
#include "GameLoop.h"
import Definitions;
class GameOverState : public State
{
public:
    GameOverState(GameDataRef data, int score);

    void Init();
    void HandleInput();
    void Update(float dt);
    void Draw(float dt);

private:
    GameDataRef _data;
    sf::Sprite _background;
    sf::Sprite replayButton;
    sf::Text scoreText;
    sf::Sprite medal;
    sf::Sprite gameOverTxt;
    int score;
};