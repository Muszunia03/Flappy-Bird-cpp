#pragma once
#include <SFML/Graphics.hpp>
#include "GameLoop.h"
#include <vector>

class Land
{
public:
	Land(GameDataRef data);
	void MoveLand(float dt);
	void DrawLand();
	const std::vector<sf::Sprite>& GetLand() const
	{
		return landSpr;
	}
private:
	GameDataRef _data;
	std::vector<sf::Sprite> landSpr;
};