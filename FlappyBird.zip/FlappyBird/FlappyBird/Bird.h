#pragma once
#pragma once
#include <SFML/Graphics.hpp>
#include "GameLoop.h"
import Definitions;

class Bird
{
public:
    Bird(GameDataRef data);
    void DrawBird();
    void Update(float dt);
    void Tap();
    bool CheckCollision(const std::vector<sf::Sprite>& pipeSprites, const std::vector<sf::Sprite>& ground);
    const sf::Sprite& GetSprite()
    {
        return birdSprite;
    }

private:
    GameDataRef _data;
    sf::Sprite birdSprite;
    sf::Texture birdTexture;
    sf::Clock clock;

    int birdState;
    float rotation;
    const float gravity = 470.0f; 
    const float jumpVelocity = 400.0f; 
    const float rotationSpeed = 200.0f; 
    const float FLYING_DURATION = 0.25f;
    const int BIRD_STATE_FALLING = 0;
    const int BIRD_STATE_FLYING = 1;
    void InitializeBird();
};

// Implementation


