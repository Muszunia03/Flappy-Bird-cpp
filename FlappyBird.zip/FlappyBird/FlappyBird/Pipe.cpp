#include "Pipe.h"
#include <iostream>

Pipe::Pipe(GameDataRef data) : _data(data)
{
    landHeight = _data->assets.GetTexture("Land").getSize().y;
    pipeOffset = 0;
    pipePassed.resize(pipeSprites.size(), false);
}

void Pipe::DrawPipes()
{
    for (int i = 0; i < pipeSprites.size(); i++)
    {
        _data->window.draw(pipeSprites.at(i));
    }
}

void Pipe::SpawnPipe(bool isTopPipe)
{
    sf::Sprite sprite(isTopPipe ? _data->assets.GetTexture("Pipe Down") : _data->assets.GetTexture("Pipe Up"));
    if (isTopPipe)
    {
        sprite.setPosition(_data->window.getSize().x, -pipeOffset);
    }
    else
    {
        sprite.setPosition(_data->window.getSize().x, _data->window.getSize().y - sprite.getGlobalBounds().height - pipeOffset);
    }
    pipeSprites.push_back(sprite);
    pipePassed.push_back(false); // Dodanie statusu przekroczenia dla nowej rury
}

void Pipe::SpawnInvisiblePipe()
{
    sf::Sprite sprite(_data->assets.GetTexture("Pipe Up"));
    sprite.setPosition(_data->window.getSize().x, _data->window.getSize().y - sprite.getGlobalBounds().height);
    sprite.setColor(sf::Color(0, 0, 0, 0));
    pipeSprites.push_back(sprite);
    pipePassed.push_back(false); // Dodanie statusu przekroczenia dla nowej rury
}

void Pipe::MovePipes(float dt)
{
    for (int i = 0; i < pipeSprites.size(); i++)
    {
        if (pipeSprites.at(i).getPosition().x < 0 - pipeSprites.at(i).getGlobalBounds().width)
        {
            pipeSprites.erase(pipeSprites.begin() + i);
            pipePassed.erase(pipePassed.begin() + i); // Usu� tak�e status przekroczenia dla tej rury
            i--; // Zmniejsz indeks, aby nie przeskakiwa� elementu
        }
        else
        {
            float movement = Definitions::PIPE_MOVEMENT_SPEED * dt;
            pipeSprites.at(i).move(-movement, 0);
        }
    }
}

void Pipe::RandomisePipe()
{
    pipeOffset = rand() % (landHeight + 1);
}

const std::vector<sf::Sprite>& Pipe::GetPipes() const
{
    return pipeSprites;
}

std::vector<bool> Pipe::GetPassed() const
{
    return pipePassed;
}

void Pipe::SetPassed(int index, bool passed)
{
    if (index >= 0 && index < pipePassed.size())
    {
        pipePassed[index] = passed;
    }
}
