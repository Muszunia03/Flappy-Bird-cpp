#pragma once

#include <sstream>
import Definitions;
#include "GameState.h"
#include "GameOverState.h"
#include <iostream>

GameState::GameState(GameDataRef data) : _data(data)
{

}

void GameState::Init()
{
	
	_data->assets.LoadTextures("Game Background", Definitions::GAME_BACKGROUND_FILEPATH);
	_data->assets.LoadTextures("Pipe Up", Definitions::PIPE_UP);
	_data->assets.LoadTextures("Pipe Down", Definitions::PIPE_DOWN);
	_data->assets.LoadTextures("Land", Definitions::LAND);
	_data->assets.LoadTextures("Bird", Definitions::BIRD_FILEPATH);
	_data->assets.LoadFont("Font", Definitions::FONT);
	pipe = new Pipe(_data);
	land = new Land(_data);
	bird = new Bird(_data);
	_background.setTexture(this->_data->assets.GetTexture("Game Background"));
	scoreText.setFont(this->_data->assets.GetFont("Font"));
	scoreText.setString("0");
	scoreText.setCharacterSize(64);
	scoreText.setFillColor(sf::Color::White);

	
	sf::FloatRect textBounds = scoreText.getLocalBounds();
	scoreText.setOrigin(textBounds.left + textBounds.width / 2.0f, textBounds.top + textBounds.height / 2.0f);
	scoreText.setPosition(static_cast<float>(_data->window.getSize().x) / 2.0f, static_cast<float>(_data->window.getSize().y) / 5.0f);
}

void GameState::HandleInput()
{
	sf::Event event;

	while (this->_data->window.pollEvent(event))
	{
		if (sf::Event::Closed == event.type)
		{
			this->_data->window.close();
		}
		if (this->_data->input.IsSpriteClicked(this->_background, sf::Mouse::Left, this->_data->window))
		{

			bird->Tap();


		}

	}
}

void GameState::Update(float dt)
{
	pipe->MovePipes(dt);
	land->MoveLand(dt);
	bird->Update(dt);
	if (clock.getElapsedTime().asSeconds() > Definitions::PIPE_SPAWN_FREQUENCY)
	{
		pipe->RandomisePipe();
		pipe->SpawnInvisiblePipe();
		pipe->SpawnPipe(false);
		pipe->SpawnPipe(true);

		clock.restart();
	}
	if (bird->CheckCollision(pipe->GetPipes(), land->GetLand()))
	{
		this->_data->machine.AddState(StateRef(new GameOverState(_data, score)), true);
	}
	auto pipes = pipe->GetPipes();
	auto passed = pipe->GetPassed();

	for (int i = 0; i < pipes.size(); i++)
	{
		// Tylko dolne rury naliczaj� wynik
		if (i % 3 == 1 && i < passed.size() && !passed[i] &&
			pipes[i].getPosition().x + pipes[i].getGlobalBounds().width < bird->GetSprite().getPosition().x)
		{
			score++;
			scoreText.setString(std::to_string(score));
			pipe->SetPassed(i, true);
		}
	}
}

void GameState::Draw(float dt)
{
	this->_data->window.clear(sf::Color::Red);

	this->_data->window.draw(this->_background);
	pipe->DrawPipes();
	land->DrawLand();
	bird->DrawBird();
	this->_data->window.draw(scoreText);
	this->_data->window.display();
}
