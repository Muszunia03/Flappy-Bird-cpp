#pragma once

#include <SFML/Graphics.hpp>
#include "State.h"
#include "GameLoop.h"
#include "Pipe.h"
#include "Land.h"
#include "Bird.h"
class GameState : public State
{
public:
	GameState(GameDataRef data);

	void Init();

	void HandleInput();
	void Update(float dt);
	void Draw(float dt);
	int getScore()
	{
		return score;
	}
private:
	GameDataRef _data;

	sf::Sprite _background;
	Pipe* pipe;
	sf::Clock clock;
	Land* land;
	Bird* bird;
	int score;
	sf::Text scoreText;
};

