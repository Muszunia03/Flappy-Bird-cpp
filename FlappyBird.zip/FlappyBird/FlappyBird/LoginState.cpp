#include "LoginState.h"
#include "MainMenuState.h"
#include <iostream>
#include <fstream>
#include <sstream>
import Definitions;
LoginState::LoginState(GameDataRef data) : _data(data), isEnteringPassword(false)
{
}

void LoginState::Init()
{
    _data->assets.LoadTextures("Login Background", Definitions::GAME_BACKGROUND_FILEPATH);
    _data->assets.LoadFont("Font", Definitions::FONT);

    _background.setTexture(this->_data->assets.GetTexture("Login Background"));

    _loginText.setFont(this->_data->assets.GetFont("Font"));
    _loginText.setString("Login:");
    _loginText.setCharacterSize(32);
    _loginText.setFillColor(sf::Color::White);
    _loginText.setPosition(100, 100);

    _passwordText.setFont(this->_data->assets.GetFont("Font"));
    _passwordText.setString("Password:");
    _passwordText.setCharacterSize(32);
    _passwordText.setFillColor(sf::Color::White);
    _passwordText.setPosition(100, 200);

    _loginMessage.setFont(this->_data->assets.GetFont("Font"));
    _loginMessage.setCharacterSize(24);
    _loginMessage.setFillColor(sf::Color::White);
    _loginMessage.setPosition(100, 150);

    _passwordMessage.setFont(this->_data->assets.GetFont("Font"));
    _passwordMessage.setCharacterSize(24);
    _passwordMessage.setFillColor(sf::Color::White);
    _passwordMessage.setPosition(100, 250);

    _loginButton.setFont(this->_data->assets.GetFont("Font"));
    _loginButton.setString("Login");
    _loginButton.setCharacterSize(32);
    _loginButton.setFillColor(sf::Color::White);
    _loginButton.setPosition(100, 300);

    _guestButton.setFont(this->_data->assets.GetFont("Font"));
    _guestButton.setString("Continue as Guest");
    _guestButton.setCharacterSize(32);
    _guestButton.setFillColor(sf::Color::White);
    _guestButton.setPosition(100, 400);

    _registerButton.setFont(this->_data->assets.GetFont("Font"));
    _registerButton.setString("Register");
    _registerButton.setCharacterSize(32);
    _registerButton.setFillColor(sf::Color::White);
    _registerButton.setPosition(100, 500);

    _errorMessage.setFont(this->_data->assets.GetFont("Font"));
    _errorMessage.setCharacterSize(24);
    _errorMessage.setFillColor(sf::Color::Red);
    _errorMessage.setPosition(100, 350);

    loadUsers();
}

void LoginState::HandleInput()
{
    sf::Event event;
    while (this->_data->window.pollEvent(event))
    {
        if (sf::Event::Closed == event.type)
        {
            this->_data->window.close();
        }
        else if (event.type == sf::Event::TextEntered)
        {
            if (event.text.unicode < 128)
            {
                char enteredChar = static_cast<char>(event.text.unicode);
                if (enteredChar == '\b')
                {
                    if (isEnteringPassword)
                    {
                        if (!password.empty())
                            password.pop_back();
                    }
                    else
                    {
                        if (!login.empty())
                            login.pop_back();
                    }
                }
                else
                {
                    if (isEnteringPassword)
                    {
                        password += enteredChar;
                    }
                    else
                    {
                        login += enteredChar;
                    }
                }
            }
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Return))
        {
            handleLogin();
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Tab) || (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left))
        {
            sf::Vector2i mousePos = sf::Mouse::getPosition(this->_data->window);
            if (_loginButton.getGlobalBounds().contains(mousePos.x, mousePos.y))
            {
                handleLogin();
            }
            else if (_guestButton.getGlobalBounds().contains(mousePos.x, mousePos.y))
            {
                this->_data->machine.AddState(StateRef(new MainMenuState(_data)), true);
            }
            else if (_registerButton.getGlobalBounds().contains(mousePos.x, mousePos.y))
            {
                handleRegister();
            }
            else if (_loginText.getGlobalBounds().contains(mousePos.x, mousePos.y))
            {
                isEnteringPassword = false;
            }
            else if (_passwordText.getGlobalBounds().contains(mousePos.x, mousePos.y))
            {
                isEnteringPassword = true;
            }
            else
            {
                isEnteringPassword = !isEnteringPassword;
            }
        }
    }
}

void LoginState::Update(float dt)
{
    _loginMessage.setString(login);
    _passwordMessage.setString(std::string(password.length(), '*'));
}

void LoginState::Draw(float dt)
{
    this->_data->window.clear();
    this->_data->window.draw(this->_background);
    this->_data->window.draw(this->_loginText);
    this->_data->window.draw(this->_passwordText);
    this->_data->window.draw(this->_loginMessage);
    this->_data->window.draw(this->_passwordMessage);
    this->_data->window.draw(this->_loginButton);
    this->_data->window.draw(this->_guestButton);
    this->_data->window.draw(this->_registerButton);
    this->_data->window.draw(this->_errorMessage);
    this->_data->window.display();
}

bool LoginState::isLoginValid(const std::string& login)
{
    std::regex loginRegex("^(?=.*\\d)[a-zA-Z\\d]{1,6}$");
    return std::regex_match(login, loginRegex);
}

bool LoginState::isPasswordValid(const std::string& password)
{
    return password.length() >= 6;
}

void LoginState::handleLogin()
{
    if (!isLoginValid(login))
    {
        _errorMessage.setString("Invalid login. Must be 1-6 characters and include at least one digit.");
        return;
    }
    if (!isPasswordValid(password))
    {
        _errorMessage.setString("Invalid password. Must be at least 6 characters.");
        return;
    }

    if (currentUser.getUsername() != login)
    {
        _errorMessage.setString("User not found. Please register.");
        return;
    }

    if (currentUser.getPassword() != password)
    {
        _errorMessage.setString("Incorrect password.");
        return;
    }

    _errorMessage.setString("");

    this->_data->machine.AddState(StateRef(new MainMenuState(_data)), true);
}

void LoginState::handleRegister()
{
    if (!isLoginValid(login))
    {
        _errorMessage.setString("Invalid login. Must be 1-6 characters and include at least one digit.");
        return;
    }
    if (!isPasswordValid(password))
    {
        _errorMessage.setString("Invalid password. Must be at least 6 characters.");
        return;
    }

    if (currentUser.getUsername() == login)
    {
        _errorMessage.setString("Username already exists.");
        return;
    }

    currentUser.setUsername(login);
    currentUser.setPassword(password);
    currentUser.setHighScore(0);

    saveUsers();

    _errorMessage.setString("User registered successfully!");
}

void LoginState::loadUsers()
{
    std::ifstream file("users.txt");
    if (file.is_open())
    {
        std::string username, password;
        int highScore;
        while (file >> username >> password >> highScore)
        {
            currentUser = User(username, password, highScore);
        }
        file.close();
    }
}

void LoginState::saveUsers()
{
    std::ofstream file("users.txt");
    if (file.is_open())
    {
        file << currentUser.toString() << "\n";
        file.close();
    }
}