#include "User.h"

User::User(const std::string& username, const std::string& password, int highScore)
    : username(username), password(password), highScore(highScore)
{
}

const std::string& User::getUsername() const
{
    return username;
}

const std::string& User::getPassword() const
{
    return password;
}

int User::getHighScore() const
{
    return highScore;
}

void User::setPassword(const std::string& password)
{
    this->password = password;
}

void User::setHighScore(int highScore)
{
    this->highScore = highScore;
}

std::string User::toString() const
{
    return username + " " + password + " " + std::to_string(highScore);
}
void User::setUsername(const std::string& username)
{
    this->username = username;
}