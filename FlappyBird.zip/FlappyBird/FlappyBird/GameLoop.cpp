#pragma once
#include "GameLoop.h"
#include "LoginState.h"
Game::Game(int width, int height, std::string title)
{
	_data->window.create(sf::VideoMode(width, height), title, sf::Style::Close | sf::Style::Titlebar);
	_data->machine.AddState(StateRef(new LoginState(this->_data)));
	this->Run();
}
void Game::Run()
{
    sf::Clock clock;
    while (this->_data->window.isOpen())
    {
        this->_data->machine.ProcessStateChanges();

        
        sf::Time elapsed = clock.getElapsedTime();
        if (elapsed.asSeconds() >= dt)
        {
            this->_data->machine.GetActiveState()->HandleInput();
            this->_data->machine.GetActiveState()->Update(dt);
            this->_data->machine.GetActiveState()->Draw(dt);

            clock.restart();  
        }
    }
}


