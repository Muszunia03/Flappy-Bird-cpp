#pragma once
#pragma once
#include <string>

class User
{
public:
    User() {};
    User(const std::string& username, const std::string& password, int highScore);
    
    const std::string& getUsername() const;
    const std::string& getPassword() const;
    int getHighScore() const;
    void setUsername(const std::string& username);
    void setPassword(const std::string& password);
    void setHighScore(int highScore);

    std::string toString() const;

private:
    std::string username;
    std::string password;
    int highScore;
};