﻿import Definitions;
#include "StateMachine.h"
#include <iostream>
#include "GameLoop.h"
#include "MainMenuState.h"




int main() 
{
    Game(Definitions::SCREEN_WIDTH, Definitions::SCREEN_HEIGHT, "Flappy Bird");
    return 0;
}
