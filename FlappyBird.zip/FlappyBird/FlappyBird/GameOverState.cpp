#include "GameOverState.h"
#include "GameState.h"
GameOverState::GameOverState(GameDataRef data, int score) : _data(data), score(score)
{
}

void GameOverState::Init()
{
    _data->assets.LoadTextures("Game Over Background", Definitions::GAME_OVER_BACKGROUND_FILEPATH);
    _data->assets.LoadTextures("Bronze Medal", Definitions::BRONZE_MEDAL);
    _data->assets.LoadTextures("Silver Medal", Definitions::SILVER_MEDAL);
    _data->assets.LoadTextures("Gold Medal", Definitions::GOLD_MEDAL);
    _data->assets.LoadFont("Font", Definitions::FONT);
    _data->assets.LoadTextures("Game Over Text", Definitions::GAME_OVER_TEXT);

    _background.setTexture(this->_data->assets.GetTexture("Game Over Background"));
    gameOverTxt.setTexture(this->_data->assets.GetTexture("Game Over Text"));
    

    scoreText.setFont(this->_data->assets.GetFont("Font"));
    scoreText.setString("Score: " + std::to_string(score));
    scoreText.setCharacterSize(64);
    scoreText.setFillColor(sf::Color::White);
    gameOverTxt.setPosition((Definitions::SCREEN_WIDTH / 2) - (gameOverTxt.getGlobalBounds().width / 2), gameOverTxt.getGlobalBounds().height / 2);

    /*_highScoreText.setFont(this->_data->assets.GetFont("Font"));
    _highScoreText.setString("High Score: " + std::to_string(_highScore));
    _highScoreText.setCharacterSize(64);
    _highScoreText.setFillColor(sf::Color::White);
    _highScoreText.setPosition(
        (_data->window.getSize().x / 2) - (_highScoreText.getGlobalBounds().width / 2),
        _data->window.getSize().y / 1.8
    );

    AssignMedal();

    SaveHighScore()*/
}

void GameOverState::HandleInput()
{
    sf::Event event;
    while (this->_data->window.pollEvent(event))
    {
        if (sf::Event::Closed == event.type)
        {
            this->_data->window.close();
        }
       
    }
}

void GameOverState::Update(float dt)
{
    
}

void GameOverState::Draw(float dt)
{
    this->_data->window.clear(sf::Color::Black);
    this->_data->window.draw(this->_background);
    this->_data->window.draw(this->gameOverTxt);
    this->_data->window.draw(this->scoreText);
    this->_data->window.display();
}