#pragma once

#include <SFML/Graphics.hpp>
#include <vector>
#include "GameLoop.h"
import Definitions;

class Pipe
{
public:
    Pipe(GameDataRef data);

    void SpawnPipe(bool isTopPipe);
    void SpawnInvisiblePipe();
    void MovePipes(float dt);
    void DrawPipes();
    void RandomisePipe();

    const std::vector<sf::Sprite>& GetPipes() const;
    std::vector<bool> GetPassed() const;
    void SetPassed(int index, bool passed);

private:
    GameDataRef _data;
    std::vector<sf::Sprite> pipeSprites;
    std::vector<bool> pipePassed;
    int landHeight;
    int pipeOffset;
};
