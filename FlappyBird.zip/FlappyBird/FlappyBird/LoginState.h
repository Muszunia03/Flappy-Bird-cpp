#pragma once
#include <SFML/Graphics.hpp>
#include <regex>
#include <map>
#include "State.h"
#include "GameLoop.h"
#include "User.h"
class LoginState : public State
{
public:
    LoginState(GameDataRef data);

    void Init();
    void HandleInput();
    void Update(float dt);
    void Draw(float dt);

private:
    GameDataRef _data;
    sf::Sprite _background;
    sf::Text _loginText;
    sf::Text _passwordText;
    sf::Text _loginMessage;
    sf::Text _passwordMessage;
    sf::Text _loginButton;
    sf::Text _guestButton;
    sf::Text _errorMessage;
    sf::Text _registerButton;
    std::string login;
    std::string password;
    bool isEnteringPassword;
    User currentUser;

    bool isLoginValid(const std::string& login);
    bool isPasswordValid(const std::string& password);
    void handleLogin();
    void loadUsers();
    void saveUsers();
    void handleRegister();
};